import json
import socket
import time
import uuid
from pathlib import Path
from threading import Lock

import requests

from mc import start_mc_collector


BASE_DIR = Path(__file__).resolve().parent

CONFIG_FILE = Path("/agibot/flag/agent/config/config.json")

SN_FILE = Path("/agibot/data/info/sn")
SKU_FILE = Path("/agibot/data/info/sku")
VERSION_FILE = Path("/agibot/software/firmware_version")


# ============================================================
# Config
# ============================================================

def load_config():
    if not CONFIG_FILE.exists():
        raise FileNotFoundError(
            f"Config file not found: {CONFIG_FILE}"
        )

    with CONFIG_FILE.open(
        "r",
        encoding="utf-8",
    ) as file:
        return json.load(file)


CONFIG = load_config()

BACKEND_URL = CONFIG["backend_url"]

HEARTBEAT_INTERVAL = CONFIG.get(
    "heartbeat_interval",
    5,
)


# ============================================================
# Robot Identity
# ============================================================

def get_robot_sn() -> str:
    """
    从机器人系统文件读取真实 SN。
    """

    try:
        sn = SN_FILE.read_text(
            encoding="utf-8"
        ).strip()

    except FileNotFoundError:
        return "SN不存在"

    except OSError:
        return "读取SN失败"

    if not sn:
        return "SN文件为空"

    return sn


def get_robot_sku() -> str:
    """
    从机器人系统文件读取真实 SKU。
    """

    try:
        sku = SKU_FILE.read_text(
            encoding="utf-8"
        ).strip()

    except FileNotFoundError:
        return "SKU不存在"

    except OSError:
        return "读取SKU失败"

    if not sku:
        return "SKU文件为空"

    return sku

def get_robot_version() -> str:
    """
    从机器人系统文件读取真实版本。
    """

    try:
        version= VERSION_FILE.read_text(
            encoding="utf-8"
        ).strip()

    except FileNotFoundError:
        return "版本不存在"

    except OSError:
        return "读取版本失败"

    if not version:
        return "版本文件为空"

    return version

ROBOT_SN = get_robot_sn()
ROBOT_SKU = get_robot_sku()
ROBOT_VERSION = get_robot_version()


# ============================================================
# Runtime State
# ============================================================

_runtime_state = "unknown"

_runtime_state_lock = Lock()


def get_runtime_state() -> str:
    """
    获取当前 MC 行动状态。
    """

    with _runtime_state_lock:
        return _runtime_state


def on_mc_state_change(state: str):
    """
    MC 状态发生变化时调用。
    """

    global _runtime_state

    with _runtime_state_lock:
        _runtime_state = state

    print(
        f"[MC] Current action state: {state}"
    )


# ============================================================
# Network
# ============================================================

def get_local_ip() -> str:

    sock = socket.socket(
        socket.AF_INET,
        socket.SOCK_DGRAM,
    )

    try:
        sock.connect(
            ("8.8.8.8", 80)
        )

        return sock.getsockname()[0]

    except OSError:
        return "127.0.0.1"

    finally:
        sock.close()


def get_mac() -> str:

    mac = uuid.getnode()

    return ":".join(
        f"{(mac >> shift) & 0xff:02x}"
        for shift in range(40, -1, -8)
    )


# ============================================================
# Backend
# ============================================================

def register():

    data = {
        "sn": ROBOT_SN,
        "sku": ROBOT_SKU,
        "ip": get_local_ip(),
        "mac": get_mac(),
        "version": get_robot_version(),
    }

    response = requests.post(
        f"{BACKEND_URL}/api/robots/register",
        json=data,
        timeout=5,
    )

    response.raise_for_status()

    print(
        "[Register] "
        f"SN={ROBOT_SN} "
        f"SKU={ROBOT_SKU}"
        f"VERSION={ROBOT_VERSION}"
    )


def heartbeat():

    data = {
        "ip": get_local_ip(),
        "mac": get_mac(),
        "status": "online",
        "runtime_state": get_runtime_state(),
    }

    response = requests.post(
        f"{BACKEND_URL}/api/robots/{ROBOT_SN}/heartbeat",
        json=data,
        timeout=5,
    )

    response.raise_for_status()

    # 保底：每次心跳顺带上报当前行动状态，确保时间线至少有一条 open event。
    # 后端会对相同状态去重（不产生重复记录），首次上报失败也能在下次心跳自愈。
    current_state = get_runtime_state()
    if current_state and current_state != "unknown":
        report_state_change(current_state)

    print(
        "[Heartbeat] "
        f"SN={ROBOT_SN} "
        f"IP={data['ip']} "
        f"STATE={data['runtime_state']}"
    )


def report_state_change(state: str):
    """
    向后端报告 MC 状态变化。
    """

    data = {
        "state": state,
        "source": "mc_event_probe",
        "event_id": 5004,
    }

    try:

        response = requests.post(
            f"{BACKEND_URL}/api/robots/"
            f"{ROBOT_SN}/state",
            json=data,
            timeout=5,
        )

        response.raise_for_status()

        print(
            "[State] "
            f"reported: {state}"
        )

    except requests.RequestException as exc:

        print(
            "[ERROR] "
            f"State report failed: {exc}"
        )


# ============================================================
# Main
# ============================================================

def main():

    print("==============================")
    print("Robot Agent")
    print("==============================")
    print(f"SN: {ROBOT_SN}")
    print(f"SKU: {ROBOT_SKU}")
    print(f"Backend: {BACKEND_URL}")
    print("==============================")

    # --------------------------------------------------------
    # 启动 ROS 2 MC Collector
    # --------------------------------------------------------

    try:

        start_mc_collector(
            on_state_change=lambda state: (
                on_mc_state_change(state),
                report_state_change(state),
            )
        )

        print(
            "[MC] Collector started"
        )

    except Exception as exc:

        print(
            "[ERROR] "
            f"Failed to start MC collector: {exc}"
        )

        print(
            "Agent will continue without MC state."
        )

    # --------------------------------------------------------
    # 注册机器人
    # --------------------------------------------------------

    while True:

        try:

            register()

            heartbeat()

            break

        except requests.RequestException as exc:

            print(
                "[ERROR] "
                f"Backend unavailable: {exc}"
            )

            print(
                "Retrying in 5 seconds..."
            )

            time.sleep(5)

    # --------------------------------------------------------
    # Heartbeat loop
    # --------------------------------------------------------

    while True:

        try:

            heartbeat()

        except requests.RequestException as exc:

            print(
                "[ERROR] "
                f"Heartbeat failed: {exc}"
            )

        except Exception as exc:

            print(
                "[ERROR] "
                f"Unexpected error: {exc}"
            )

        time.sleep(
            HEARTBEAT_INTERVAL
        )


if __name__ == "__main__":
    main()